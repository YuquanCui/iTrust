/**
 * The controllers.api package is for storing all controllers that will respond
 * to REST API endpoints.
 * 
 * @author Kai Presler-Marshall
 */
package edu.ncsu.csc.itrust2.controllers.api;
