package edu.ncsu.csc.itrust2.models.enums;

import java.util.HashMap;
import java.util.Map;

public enum MealType {

    /**
     * Breakfast
     */
    Breakfast ( "Breakfast" ),
    /**
     * Lunch
     */
    Lunch ( "Lunch" ),
    /**
     * Dinner
     */
    Dinner ( "Dinner" ),
    /**
     * Snack
     */
    Snack ( "Snack" ),

    /**
     * Type used to hold totals
     */
    Totals ( "Totals" );

    /**
     * Type of the meal
     */
    private String type;

    /**
     * Constructor for MealType.
     *
     * @param name
     *            Name of the MealType to create
     */
    private MealType ( final String type ) {
        this.type = type;
    }

    /**
     * Retrieve the Name of the MealType
     *
     * @return Name of the MealType
     */
    public String getName () {
        return this.type;
    }

    /**
     * Returns a map from field name to value, which is more easily serialized
     * for sending to front-end.
     *
     * @return map from field name to value for each of the fields in this enum
     */
    public Map<String, Object> getInfo () {
        final Map<String, Object> map = new HashMap<String, Object>();
        map.put( "id", name() );
        map.put( "name", getName() );
        return map;
    }

    /**
     * Convert the MealType to a String
     */
    @Override
    public String toString () {
        return getName();
    }

    /**
     * Find the matching MealType for the string provided.
     *
     * @param mealtypeStr
     *            MealType String to find an MealType Enum for
     * @return The MealType parsed
     */
    public static MealType parse ( final String mealtypeStr ) {
        for ( final MealType mealtype : values() ) {
            if ( mealtype.getName().equals( mealtypeStr ) ) {
                return mealtype;
            }
        }
        return null;
    }

}
