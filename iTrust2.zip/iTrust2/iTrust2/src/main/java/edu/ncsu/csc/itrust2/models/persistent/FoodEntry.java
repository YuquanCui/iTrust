package edu.ncsu.csc.itrust2.models.persistent;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.ObjectNotFoundException;
import org.hibernate.criterion.Criterion;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import edu.ncsu.csc.itrust2.forms.foodEntry.FoodEntryForm;
import edu.ncsu.csc.itrust2.models.enums.MealType;
import edu.ncsu.csc.itrust2.models.enums.Role;

/**
 * Represent a single Food Entry model
 *
 * @author ycui9 Yuquan Cui
 *
 */
@Entity
@Table ( name = "FoodEntries" )
public class FoodEntry extends DomainObject<FoodEntry> {

    /**
     * Empty constructor for Hibernate.
     */
    public FoodEntry () {
    }

    /**
     * Constructs a new form from the details in the given form
     *
     * @param form
     *            the form to base the new entry on
     */
    public FoodEntry ( final FoodEntryForm form ) {
        if ( form.getId() != null ) {
            setId( form.getId() );
        }

        final SimpleDateFormat sdf = new SimpleDateFormat( "MM/dd/yyyy", Locale.ENGLISH );
        Date parsedDate = null;
        try {
            parsedDate = sdf.parse( form.getDate() );
        }
        catch ( final ParseException e ) {
            // Ignore, Hibernate will catch the null date
        }
        final Calendar c = Calendar.getInstance();
        c.setTime( parsedDate );
        this.setDate( c );

        this.setMealType( MealType.parse( form.getmealType() ) );
        this.setFoodName( form.getFoodName() );
        this.setNumServings( form.getNumServings() );
        this.setCaloriesPerServing( form.getCaloriesPerServing() );
        this.setFatPerServing( form.getFatPerServing() );
        this.setSodiumPerServing( form.getSodiumPerServing() );
        this.setCarbsPerServing( form.getCarbsPerServing() );
        this.setSugarsPerServing( form.getSugarsPerServing() );
        this.setFiberPerServing( form.getFiberPerServing() );
        this.setProteinPerServing( form.getProteinPerServing() );
        this.setPatient( User.getByName( form.getPatient() ) );

    }

    /** entry id */
    @Id
    @GeneratedValue ( strategy = GenerationType.AUTO )
    private long     id;

    /** entry date */
    @NotNull
    private Calendar date;

    /** entry meal type */
    @Enumerated ( EnumType.STRING )
    private MealType mealType;

    private boolean  isTotal;

    /** food name */
    @NotEmpty
    @NotNull
    @Length ( max = 64 )
    private String   name;

    /** number of servings */
    @Min ( 1 )
    private int      servings;

    /** calories per servings */
    @Min ( 0 )
    private int      calories;

    /** grams of fat per serving */
    @Min ( 0 )
    private int      fat;

    /** milligrams of sodium per serving */
    @Min ( 0 )
    private int      sodium;

    /** grams of carbs per serving */
    @Min ( 0 )
    private int      carbs;

    /** grams of sugar per serving */
    @Min ( 0 )
    private int      sugar;

    /** grams of fiber per serving */
    @Min ( 0 )
    private int      fiber;

    /** grams of protein per serving */
    @Min ( 0 )
    private int      protein;

    /** The patient who is associated with this entry */
    @NotNull
    @ManyToOne
    @JoinColumn ( name = "patient_id", columnDefinition = "varchar(100)" )
    private User     patient;

    /**
     * Set the food entry ID
     *
     * @param id
     *            entry id
     */
    public void setId ( final Long id ) {
        this.id = id;
    }

    /**
     * Set the date of the entry current or past dates
     *
     * @param date
     *            current or past dates
     */
    public void setDate ( final Calendar date ) {
        this.date = date;
    }

    /**
     * Set the type of the meal type
     *
     * @param type
     *            meal type
     */
    public void setMealType ( final MealType type ) {
        this.mealType = type;
    }

    /**
     * set the name of food
     *
     * @param foodName
     *            food name
     */
    public void setFoodName ( final String foodName ) {
        this.name = foodName;
    }

    /**
     * set the num of servings
     *
     * @param numServings
     *            num of servings
     */
    public void setNumServings ( final int numServings ) {
        this.servings = numServings;
    }

    /**
     * Set the calories per serving for this entry
     *
     * @param cal
     *            calories
     */
    public void setCaloriesPerServing ( final int cal ) {
        this.calories = cal;
    }

    /**
     * Set the grams of fat per serving this entry
     *
     * @param fat
     *            fat
     */
    public void setFatPerServing ( final int fat ) {
        this.fat = fat;
    }

    /**
     * set the milligrams of sodium per serving
     *
     * @param sodium
     *            milligrams of sodium per serving
     */
    public void setSodiumPerServing ( final int sodium ) {
        this.sodium = sodium;
    }

    /**
     * set the grams of carbs per serving this entry
     *
     * @param carbs
     *            grams of carbs per serving this entry
     */
    public void setCarbsPerServing ( final int carbs ) {
        this.carbs = carbs;
    }

    /**
     * set the grams of sugars per serving this entry
     *
     * @param sugar
     *            grams of sugars per serving this entry
     */
    public void setSugarsPerServing ( final int sugar ) {
        this.sugar = sugar;
    }

    /**
     * set the grams of fiber per serving
     *
     * @param fiber
     *            grams of fiber per serving
     */
    public void setFiberPerServing ( final int fiber ) {
        this.fiber = fiber;
    }

    /**
     * set the grams of protein per serving this entry
     *
     * @param protein
     *            grams of protein per serving this entry
     */
    public void setProteinPerServing ( final int protein ) {
        this.protein = protein;
    }

    /**
     * set the patient's name for this entry
     *
     * @param user
     *            patient's name for this entry
     */
    public void setPatient ( final User user ) {
        this.patient = user;
    }

    /**
     * Return the entry id
     *
     * @return id
     */
    @Override
    public Long getId () {
        return this.id;
    }

    /**
     * Return the date associated with this entry
     *
     * @return date
     */
    public Calendar getDate () {
        return this.date;
    }

    /**
     * Return the food name of this entry
     *
     * @return the name of the food
     */
    public String getFoodName () {
        return this.name;
    }

    /**
     * Return the meal type of this entry
     *
     * @return mealType
     */
    public MealType getmeal () {
        return this.mealType;
    }

    /**
     * Return this number of servings for this entry
     *
     * @return num_servings
     */
    public int getNumServings () {
        return this.servings;
    }

    /**
     * Return the calories per serving
     *
     * @return calories per serving
     */
    public int getCaloriesPerServing () {
        return this.calories;
    }

    /**
     * Return the grams of fat per serving
     *
     * @return grams_fat_per_serving
     */
    public int getFatPerServing () {
        return this.fat;
    }

    /**
     * Return the milligrams of sodium per serving
     *
     * @return migrams_sodium_per_serving
     */
    public int getSodiumPerServing () {
        return this.sodium;
    }

    /**
     * Return the grams of carbs per serving
     *
     * @return grams_carbs_per_serving
     */
    public int getCarbsPerServing () {
        return this.carbs;
    }

    /**
     * Return the grams of sugars per serving
     *
     * @return grams_sugar_per_serving
     */
    public int getSugarsPerServing () {
        return this.sugar;
    }

    /**
     * Return the grams of fiber per serving
     *
     * @return grams_fiber_per_serving
     */
    public int getFiberPerServing () {
        return this.fiber;
    }

    /**
     * Return the grams of protein per serving
     *
     * @return grams_protein_per_serving
     */
    public int getProteinPerServing () {
        return this.protein;
    }

    /**
     * Return the patient's name associated with this entry
     *
     * @return patient
     */
    public User getPatient () {
        return this.patient;
    }

    /**
     * Return whether this entry is a total
     *
     * @return true if this entry is used for totals
     */
    public boolean getIsTotal () {
        return this.isTotal;
    }

    /**
     * Rerieve all Entries for the patient provided
     *
     * @param patient
     *            The Patient to add Entries for
     * @return The List of records that was found
     */
    public static List<FoodEntry> getForPatient ( final String patient ) {
        return getWhere( eqList( "patient", User.getByNameAndRole( patient, Role.ROLE_PATIENT ) ) );
    }

    /**
     * Returns a collection of food entries that meet the "where" query
     *
     * @param where
     *            List of Criterion to and together and search for records by
     * @return a collection of matching food entries
     */
    @SuppressWarnings ( "unchecked" )
    private static List<FoodEntry> getWhere ( final List<Criterion> where ) {
        return (List<FoodEntry>) getWhere( FoodEntry.class, where );
    }

    /**
     * Gets the FoodEntry with the given id, or null if none exists.
     *
     * @param id
     *            the id to query for
     * @return the matching Food Entry
     */
    public static FoodEntry getById ( final Long id ) {
        try {
            return getWhere( eqList( ID, id ) ).get( 0 );
        }
        catch ( final ObjectNotFoundException e ) {
            return null;
        }
    }

    /**
     * Gets a collection of all the Food Entries in the system.
     *
     * @return the system's food entries
     */
    @SuppressWarnings ( "unchecked" )
    public static List<FoodEntry> getFoodEntries () {
        return (List<FoodEntry>) DomainObject.getAll( FoodEntry.class );
    }
}
