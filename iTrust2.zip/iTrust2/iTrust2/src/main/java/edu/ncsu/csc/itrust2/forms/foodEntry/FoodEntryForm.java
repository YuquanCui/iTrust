package edu.ncsu.csc.itrust2.forms.foodEntry;

import java.text.SimpleDateFormat;
import java.util.Locale;

import edu.ncsu.csc.itrust2.models.persistent.FoodEntry;

/**
 * A form for REST API communication. Contains fields for constructing FoodEntry
 * objects.
 *
 * @author Yuquan Cui ycui9
 */
public class FoodEntryForm {

    /** entry id */
    private long   id;

    /** entry date */
    private String date;

    /** entry meal type */
    private String type;

    /** food name */
    private String name;

    /** number of servings */
    private int    servings;

    /** calories per servings */
    private int    calories;

    /** grams of fat per serving */
    private int    fat;

    /** milligrams of sodium per serving */
    private int    sodium;

    /** grams of carbs per serving */
    private int    carbs;

    /** grams of sugar per serving */
    private int    sugar;

    /** grams of fiber per serving */
    private int    fiber;

    /** grams of protein per serving */
    private int    protein;

    /** patient's name */
    private String patient;

    /**
     * Empty constructor for filling in fields without a food entry object.
     */
    public FoodEntryForm () {

    }

    /**
     * Constructs a new form with information from the given food entry.
     *
     * @param fe
     *            the food entry object
     */
    public FoodEntryForm ( final FoodEntry fe ) {
        this.setId( fe.getId() );
        setPatient( fe.getPatient().getUsername() );
        final SimpleDateFormat tempDate = new SimpleDateFormat( "MM/dd/yyyy", Locale.ENGLISH );
        this.setDate( tempDate.format( fe.getDate().getTime() ) );
        if ( null != fe.getmeal() ) {
            this.setMealType( fe.getmeal().toString() );
        }
        this.setFoodName( fe.getFoodName() );
        this.setNumServings( fe.getNumServings() );
        this.setCaloriesPerServing( fe.getCaloriesPerServing() );
        this.setFatPerServing( fe.getFatPerServing() );
        this.setSodiumPerServing( fe.getSodiumPerServing() );
        this.setCarbsPerServing( fe.getCarbsPerServing() );
        this.setSugarsPerServing( fe.getSugarsPerServing() );
        this.setFiberPerServing( fe.getFiberPerServing() );
        this.setProteinPerServing( fe.getProteinPerServing() );
        this.setPatient( fe.getPatient().getUsername() );

    }

    /**
     * Set the food entry ID
     *
     * @param id
     *            entry id
     */
    public void setId ( final Long id ) {
        this.id = id;
    }

    /**
     * Set the date of the entry current or past dates
     *
     * @param date
     *            current or past dates
     */
    public void setDate ( final String date ) {
        this.date = date;
    }

    /**
     * Set the type of the meal type
     *
     * @param type
     *            meal type
     */
    public void setMealType ( final String type ) {
        this.type = type;
    }

    /**
     * set the name of food
     *
     * @param foodName
     *            food name
     */
    public void setFoodName ( final String foodName ) {
        this.name = foodName;
    }

    /**
     * set the num of servings
     *
     * @param numServings
     *            num of servings
     */
    public void setNumServings ( final int numServings ) {
        this.servings = numServings;
    }

    /**
     * Set the calories per serving for this entry
     *
     * @param calories
     *            calories
     */
    public void setCaloriesPerServing ( final int calories ) {
        this.calories = calories;
    }

    /**
     * Set the grams of fat per serving this entry
     *
     * @param fat
     *            fat
     */
    public void setFatPerServing ( final int fat ) {
        this.fat = fat;
    }

    /**
     * set the milligrams of sodium per serving
     *
     * @param sodium
     *            milligrams of sodium per serving
     */
    public void setSodiumPerServing ( final int sodium ) {
        this.sodium = sodium;
    }

    /**
     * set the grams of carbs per serving this entry
     *
     * @param carbs
     *            grams of carbs per serving this entry
     */
    public void setCarbsPerServing ( final int carbs ) {
        this.carbs = carbs;
    }

    /**
     * set the grams of sugars per serving this entry
     *
     * @param sugar
     *            grams of sugars per serving this entry
     */
    public void setSugarsPerServing ( final int sugar ) {
        this.sugar = sugar;
    }

    /**
     * set the grams of fiber per serving
     *
     * @param fiber
     *            grams of fiber per serving
     */
    public void setFiberPerServing ( final int fiber ) {
        this.fiber = fiber;
    }

    /**
     * set the grams of protein per serving this entry
     *
     * @param protein
     *            grams of protein per serving this entry
     */
    public void setProteinPerServing ( final int protein ) {
        this.protein = protein;
    }

    /**
     * set the patient's name for this entry
     *
     * @param user
     *            patient's name for this entry
     */
    public void setPatient ( final String user ) {
        this.patient = user;
    }

    /**
     * Return the entry id
     *
     * @return id
     */
    public Long getId () {
        return this.id;
    }

    /**
     * Return the date associated with this entry
     *
     * @return date
     */
    public String getDate () {
        return this.date;
    }

    /**
     * Return the food name of this entry
     *
     * @return the name of the food
     */
    public String getFoodName () {
        return this.name;
    }

    /**
     * Return the meal type of this entry
     *
     * @return mealType
     */
    public String getmealType () {
        return this.type;
    }

    /**
     * Return this number of servings for this entry
     *
     * @return num_servings
     */
    public int getNumServings () {
        return this.servings;
    }

    /**
     * Return the calories per serving
     *
     * @return calories per serving
     */
    public int getCaloriesPerServing () {
        return this.calories;
    }

    /**
     * Return the grams of fat per serving
     *
     * @return grams_fat_per_serving
     */
    public int getFatPerServing () {
        return this.fat;
    }

    /**
     * Return the milligrams of sodium per serving
     *
     * @return migrams_sodium_per_serving
     */
    public int getSodiumPerServing () {
        return this.sodium;
    }

    /**
     * Return the grams of carbs per serving
     *
     * @return grams_carbs_per_serving
     */
    public int getCarbsPerServing () {
        return this.carbs;
    }

    /**
     * Return the grams of sugars per serving
     *
     * @return grams_sugar_per_serving
     */
    public int getSugarsPerServing () {
        return this.sugar;
    }

    /**
     * Return the grams of fiber per serving
     *
     * @return grams_fiber_per_serving
     */
    public int getFiberPerServing () {
        return this.fiber;
    }

    /**
     * Return the grams of protein per serving
     *
     * @return grams_protein_per_serving
     */
    public int getProteinPerServing () {
        return this.protein;
    }

    /**
     * Return the patient's name associated with this entry
     *
     * @return patient
     */
    public String getPatient () {
        return this.patient;
    }

}
