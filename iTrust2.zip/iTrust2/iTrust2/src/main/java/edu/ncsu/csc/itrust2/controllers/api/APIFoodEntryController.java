package edu.ncsu.csc.itrust2.controllers.api;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import edu.ncsu.csc.itrust2.forms.foodEntry.FoodEntryForm;
import edu.ncsu.csc.itrust2.models.enums.TransactionType;
import edu.ncsu.csc.itrust2.models.persistent.FoodEntry;
import edu.ncsu.csc.itrust2.utils.LoggerUtil;

/**
 * Provides REST endpoints that deal with Food Diary Entry. Exposes
 * functionality to add an entry and get/view entries.
 *
 * @author Yuquan Cui
 */
@RestController
@SuppressWarnings ( { "rawtypes", "unchecked" } )
public class APIFoodEntryController extends APIController {

    /**
     * Return the food diary entries for a single patient with a patient's name.
     * This was created following the pattern of various other api classes.
     *
     * @param patient
     *            the patient to get
     * @return the food diary entries
     */
    @PreAuthorize ( "hasAnyRole('ROLE_HCP', 'ROLE_PATIENT')" )
    @GetMapping ( BASE_PATH + "/foodDiaryEntries/{patient}" )
    public List<FoodEntry> getPatientFoodEntries ( @PathVariable final String patient ) {
        final List<FoodEntry> fe = FoodEntry.getForPatient( patient );

        final boolean isHCP = SecurityContextHolder.getContext().getAuthentication().getAuthorities()
                .contains( new SimpleGrantedAuthority( "ROLE_HCP" ) );
        if ( isHCP ) {
            if ( fe == null ) {
                LoggerUtil.log( TransactionType.HCP_VIEW_ENTRIES, LoggerUtil.currentUser(),
                        "Failed to find entries by HCP with patient " + patient );
            }
            return FoodEntry.getForPatient( patient );

        }
        else {
            if ( fe == null ) {
                LoggerUtil.log( TransactionType.PATIENT_VIEW_ENTRIES, LoggerUtil.currentUser(),
                        "Failed to find entries by patient with patient " + patient );
            }
            return FoodEntry.getForPatient( patient );

        }

    }

    /**
     * Adds a single food diary entry for a patient in the system. No
     * requirements needed. This was created following the pattern of various
     * other api classes
     *
     * @param form
     *            details of the new food diary entry
     * @return the created food diary entry
     */
    @PreAuthorize ( "hasRole('ROLE_PATIENT')" )
    @PostMapping ( BASE_PATH + "/foodDiaryEntries" )
    public ResponseEntity addAnEntry ( @RequestBody final FoodEntryForm form ) {
        try {
            final FoodEntry fe = new FoodEntry( form );
            fe.save();
            LoggerUtil.log( TransactionType.PATIENT_CREATE_ENTRY, LoggerUtil.currentUser(),
                    fe.getPatient().getUsername(), "Created a food diary entry with id " + fe.getId() );
            return new ResponseEntity( fe, HttpStatus.OK );
        }
        catch ( final Exception e ) {
            LoggerUtil.log( TransactionType.PATIENT_CREATE_ENTRY, LoggerUtil.currentUser(),
                    "Failed to create an food diary entry" );
            return new ResponseEntity( errorResponse( "Could not save the food diary entry: " + e.getMessage() ),
                    HttpStatus.BAD_REQUEST );
        }

    }

}
