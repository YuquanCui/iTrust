/**
 * Utils for aiding with testing purposes
 * 
 * @author Kai Presler-Marshall
 */
package edu.ncsu.csc.itrust2.utils;
