package edu.ncsu.csc.itrust2.apitest;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.UnsupportedEncodingException;

import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import edu.ncsu.csc.itrust2.config.RootConfiguration;
import edu.ncsu.csc.itrust2.forms.foodEntry.FoodEntryForm;
import edu.ncsu.csc.itrust2.models.persistent.FoodEntry;
import edu.ncsu.csc.itrust2.mvc.config.WebMvcConfiguration;

@RunWith ( SpringJUnit4ClassRunner.class )
@ContextConfiguration ( classes = { RootConfiguration.class, WebMvcConfiguration.class } )
@WebAppConfiguration
public class APIFoodDiaryTest {
	 private MockMvc               mvc;
	 @Autowired
	    private WebApplicationContext context;
	 
	    /**
	     * Performs setup operations for the tests.
	     */
	    @Before
	    public void setup () {
	    	mvc = MockMvcBuilders.webAppContextSetup( context ).build();
	    }
	    
	    /**
	     * Tests basic FoodDiary API functionality and validly add food diary entries.
	     * @throws Exception 
	     * @throws UnsupportedEncodingException 
	     */
	    @Test
	    @WithMockUser ( username = "patient", roles = { "USER", "PATIENT"  } )
	    public void testFoodEntryAPI_valid () throws UnsupportedEncodingException, Exception {
	    	// Create food diary entries form for testing
	    	   final FoodEntryForm form1 = new FoodEntryForm();
	    	   form1.setDate("10/15/2018");
	    	   form1.setMealType("Breakfast");
	    	   form1.setFoodName("Test1");
	    	   form1.setNumServings(10);
	    	   form1.setCaloriesPerServing(130);
	    	   form1.setFatPerServing(2);
	    	   form1.setSodiumPerServing(2);
	    	   form1.setCarbsPerServing(2);
	    	   form1.setSugarsPerServing(2);
	    	   form1.setFiberPerServing(2);
	    	   form1.setProteinPerServing(2);
	    	   form1.setPatient("patient");
	    	   
	    	   final FoodEntryForm form2 = new FoodEntryForm();
	    	   form2.setDate("10/15/2018");
	    	   form2.setMealType("Lunch");
	    	   form2.setFoodName("Test2");
	    	   
	    	   form2.setNumServings(10);
	    	   form2.setCaloriesPerServing(160);
	    	   form2.setFatPerServing(5);
	    	   form2.setSodiumPerServing(5);
	    	   form2.setCarbsPerServing(5);
	    	   form2.setSugarsPerServing(5);
	    	   form2.setFiberPerServing(5);
	    	   form2.setProteinPerServing(5);
	    	   form2.setPatient("patient");
	    	   
	    	// Add entry 1 to system
	    	   final String content1 = mvc
	    			   .perform(post( "/api/v1/foodDiaryEntries" ).contentType( MediaType.APPLICATION_JSON )
	    					   .content(TestUtils.asJsonString( form1 ) ) )
	    			   .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();	    	   
	    	   
	    	// Parse response as FoodEntry object
	    	   final Gson gson = new GsonBuilder().create();
	    	   final FoodEntry foodEntry1 = gson.fromJson( content1, FoodEntry.class );
	    	   assertEquals( form1.getFoodName(), foodEntry1.getFoodName());
	    	   assertEquals( form1.getNumServings(), foodEntry1.getNumServings());
	    	   assertEquals( form1.getCaloriesPerServing(), foodEntry1.getCaloriesPerServing());
	    	   assertEquals( form1.getFatPerServing(), foodEntry1.getFatPerServing());
	    	   assertEquals( form1.getSodiumPerServing(), foodEntry1.getSodiumPerServing());
	    	   assertEquals( form1.getCarbsPerServing(), foodEntry1.getCarbsPerServing());
	    	   assertEquals( form1.getSugarsPerServing(), foodEntry1.getSugarsPerServing());
	    	   assertEquals( form1.getFiberPerServing(), foodEntry1.getFiberPerServing());
	    	   assertEquals( form1.getProteinPerServing(), foodEntry1.getProteinPerServing());
	    	   
	    	// Attempt to add the same entry twice
	    	   /**
	    	   mvc.perform( post( "/api/v1/patient" ).contentType( MediaType.APPLICATION_JSON )
	                   .content( TestUtils.asJsonString( form1 ) ) ).andExpect( status().isConflict() );
	                   **/
	    	
	    	// Add entry 2 to system
	    	   final String content2 = mvc
	    			   .perform(post( "/api/v1/foodDiaryEntries" ).contentType( MediaType.APPLICATION_JSON )
	    					   .content(TestUtils.asJsonString( form2 ) ) )
	    			   .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();	
	    	// Parse response as FoodEntry object
	    	   final FoodEntry foodEntry2 = gson.fromJson( content2, FoodEntry.class );
	    	   assertEquals( form2.getFoodName(), foodEntry2.getFoodName());
	    	   assertEquals( form2.getNumServings(), foodEntry2.getNumServings());
	    	   assertEquals( form2.getCaloriesPerServing(), foodEntry2.getCaloriesPerServing());
	    	   assertEquals( form2.getFatPerServing(), foodEntry2.getFatPerServing());
	    	   assertEquals( form2.getSodiumPerServing(), foodEntry2.getSodiumPerServing());
	    	   assertEquals( form2.getCarbsPerServing(), foodEntry2.getCarbsPerServing());
	    	   assertEquals( form2.getSugarsPerServing(), foodEntry2.getSugarsPerServing());
	    	   assertEquals( form2.getFiberPerServing(), foodEntry2.getFiberPerServing());
	    	   assertEquals( form2.getProteinPerServing(), foodEntry2.getProteinPerServing());
	    	   
	    	
	    	// Verify food diary entries have been added
	    	   mvc.perform( get( "/api/v1/foodDiaryEntries/patient" ) ).andExpect( status().isOk() )
               .andExpect( content().string( Matchers.containsString( form1.getFoodName() ) ) )
               .andExpect( content().string( Matchers.containsString( form2.getFoodName() ) ) );
	    
	
	    	   
	    }
	    
	    
	    /**
	     * Mock patient to add invalidly
	     * @throws UnsupportedEncodingException
	     * @throws Exception
	     */
	    @Test
	    @WithMockUser ( username = "patient", roles = { "USER", "PATIENT"  } )
	    public void testFoodEntryAPI_invalid () throws UnsupportedEncodingException, Exception {
	    	// Attempt to add invalidly form3, should print "Failed to create an food diary entry"
	    	   final FoodEntryForm form3 = new FoodEntryForm();
	    	   form3.setDate("10/20/2018");
	    	   form3.setMealType("Dinner");
	    	   form3.setFoodName("Test3_invalid");
	    	   form3.setNumServings(-1);
	    	   form3.setCaloriesPerServing(160);
	    	   form3.setFatPerServing(5);
	    	   form3.setSodiumPerServing(5);
	    	   form3.setCarbsPerServing(5);
	    	   form3.setSugarsPerServing(5);
	    	   form3.setFiberPerServing(5);
	    	   form3.setProteinPerServing(5);	
	    	   
	    	   final String content3 = mvc
	    			   .perform(post( "/api/v1/foodDiaryEntries" ).contentType( MediaType.APPLICATION_JSON )
	    					   .content(TestUtils.asJsonString( form3 ) ) )
	    			   .andExpect( status().isBadRequest() ).andReturn().getResponse().getContentAsString();
	    	   
	    	   
	    	// Attempt to add invalidly form4, should print "Failed to create an food diary entry"
	    	   final FoodEntryForm form4 = new FoodEntryForm();
	    	   form4.setDate("wwwwwwwww");
	    	   form4.setMealType("Dinner");
	    	   form4.setFoodName("Test4_invalid");
	    	   form4.setNumServings(10);
	    	   form4.setCaloriesPerServing(160);
	    	   form4.setFatPerServing(5);
	    	   form4.setSodiumPerServing(5);
	    	   form4.setCarbsPerServing(5);
	    	   form4.setSugarsPerServing(5);
	    	   form4.setFiberPerServing(5);
	    	   form4.setProteinPerServing(5);	
	    	   
	    	   final String content4 = mvc
	    			   .perform(post( "/api/v1/foodDiaryEntries" ).contentType( MediaType.APPLICATION_JSON )
	    					   .content(TestUtils.asJsonString( form4 ) ) )
	    			   .andExpect( status().isBadRequest() ).andReturn().getResponse().getContentAsString();
	    	   
	    	// Attempt to add invalidly form5, should print "Failed to create an food diary entry"
	    	   final FoodEntryForm form5 = new FoodEntryForm();
	    	   form5.setDate("10/20/2018");
	    	   form5.setMealType("One");
	    	   form5.setFoodName("Test5_invalid");
	    	   form5.setNumServings(10);
	    	   form5.setCaloriesPerServing(160);
	    	   form5.setFatPerServing(5);
	    	   form5.setSodiumPerServing(5);
	    	   form5.setCarbsPerServing(5);
	    	   form5.setSugarsPerServing(5);
	    	   form5.setFiberPerServing(5);
	    	   form5.setProteinPerServing(5);	
	    	   
	    	   final String content5 = mvc
	    			   .perform(post( "/api/v1/foodDiaryEntries" ).contentType( MediaType.APPLICATION_JSON )
	    					   .content(TestUtils.asJsonString( form5 ) ) )
	    			   .andExpect( status().isBadRequest() ).andReturn().getResponse().getContentAsString();
	    }
	   
	    
	   
	    
}
