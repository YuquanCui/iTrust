package edu.ncsu.csc.itrust2.cucumber;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Calendar;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import edu.ncsu.csc.itrust2.models.persistent.Patient;
import edu.ncsu.csc.itrust2.models.persistent.User;

public class HCPFoodDiariesStepDef extends CucumberTest {

    // the methods below are reused from PersonalRepresentativesStepDefs with a
    // few changes

    private final String baseUrl = "http://localhost:8080/iTrust2";

    // Taken from PersonalRepresentativesStepDef
    private void setTextField ( final By byval, final Object value ) {
        final WebElement elem = driver.findElement( byval );
        elem.clear();
        elem.sendKeys( value.toString() );
    }

    // taken from PrescriptionsStepDef
    private void enterValue ( final String name, final String value ) {
        final WebElement field = driver.findElement( By.name( name ) );
        field.clear();
        field.sendKeys( String.valueOf( value ) );
    }

    /**
     * Login as admin and create users Luke and Obiwan
     */
    @Given ( "the relevant users exist in the system" )
    public void createTheUsers () {
        attemptLogout();

        waitForAngular();
        driver.get( baseUrl );
        setTextField( By.name( "username" ), "admin" );
        setTextField( By.name( "password" ), "123456" );
        driver.findElement( By.className( "btn" ) ).click();
        waitForAngular();

        ( (JavascriptExecutor) driver ).executeScript( "document.getElementById('users').click();" );
        waitForAngular();

        setTextField( By.name( "username" ), "Luke" );
        setTextField( By.name( "password" ), "123456" );
        setTextField( By.name( "password2" ), "123456" );
        final Select dropdown = new Select( driver.findElement( By.id( "role" ) ) );
        dropdown.selectByVisibleText( "Patient" );
        driver.findElement( By.name( "enabled" ) ).click();
        driver.findElement( By.id( "submit" ) ).click();
        final Patient wario = new Patient();
        waitForAngular();
        wario.setSelf( User.getByName( "Luke" ) );
        wario.setFirstName( "Luke" );
        wario.setLastName( "Skywalker" );
        final Calendar warioBirth = Calendar.getInstance();
        warioBirth.add( Calendar.YEAR, -13 ); // alice is thirteen years old
        wario.setDateOfBirth( warioBirth );
        wario.save();

        waitForAngular();
        ( (JavascriptExecutor) driver ).executeScript( "document.getElementById('users').click();" );
        waitForAngular();

        setTextField( By.name( "username" ), "Obiwan" );
        setTextField( By.name( "password" ), "123456" );
        setTextField( By.name( "password2" ), "123456" );
        final Select other = new Select( driver.findElement( By.id( "role" ) ) );
        other.selectByVisibleText( "Patient" );
        driver.findElement( By.name( "enabled" ) ).click();
        driver.findElement( By.id( "submit" ) ).click();

        final Patient waluigi = new Patient();
        waitForAngular();
        waluigi.setSelf( User.getByName( "Obiwan" ) );
        waluigi.setFirstName( "Obiwan" );
        waluigi.setLastName( "Kenobi" );
        final Calendar waluigiBirth = Calendar.getInstance();
        waluigiBirth.add( Calendar.YEAR, -13 ); // alice is thirteen years old
        waluigi.setDateOfBirth( waluigiBirth );
        waluigi.save();
        waitForAngular();

    }

    /**
     * Login as patient Luke
     */
    @Given ( "A patient logs in" )
    public void loginAsLuigi () {
        attemptLogout();

        driver.get( baseUrl );
        setTextField( By.name( "username" ), "Luke" );
        setTextField( By.name( "password" ), "123456" );
        driver.findElement( By.className( "btn" ) ).click();

        waitForAngular();
    }

    /**
     * View food diary
     */
    @And ( "Navigates to their food diary" )
    public void viewFoodDiary () {
        waitForAngular();
        ( (JavascriptExecutor) driver ).executeScript( "document.getElementById('fooddiary').click();" );
        waitForAngular();

    }

    /**
     * Navigate to add an entry
     */
    @And ( "Navigates to the page to add an entry" )
    public void addFoodEntry () {
        waitForAngular();
        ( (JavascriptExecutor) driver ).executeScript( "document.getElementById('newEntryButton').click();" );
        waitForAngular();
    }

    /**
     * Fill in food information with the information
     *
     * @param date
     *            date to use
     * @param type
     *            meal type
     * @param name
     *            name of food
     * @param servings
     *            servings of food
     * @param calories
     *            calories of food
     * @param fat
     *            fat of food
     * @param sodium
     *            sodium of food
     * @param carbs
     *            carbs of food
     * @param sugar
     *            sugar of food
     * @param fiber
     *            fiber of food
     * @param protein
     *            protein of food
     */
    @And ( "fills in the form with the information: (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+)" )
    public void fillInForm ( final String date, final String type, final String name, final String servings,
            final String calories, final String fat, final String sodium, final String carbs, final String sugar,
            final String fiber, final String protein ) {
        waitForAngular();

        waitForAngular();
        enterValue( "date", date );
        enterValue( "name", name );
        enterValue( "servings", servings );
        enterValue( "calories", calories );
        enterValue( "fat", fat );

        // This was found at the following website:
        // https://loadfocus.com/blog/2016/06/13/how-to-select-a-dropdown-in-selenium-webdriver-using-java/
        final Select dropdown = new Select( driver.findElement( By.name( "type" ) ) );
        dropdown.selectByVisibleText( type );
        // end credited code

        enterValue( "carbs", carbs );
        enterValue( "sugar", sugar );
        enterValue( "fiber", fiber );
        enterValue( "protein", protein );
        waitForAngular();
    }

    /**
     * Submit the food entry as a patient
     */
    @And ( "submits the food entry" )
    public void submitFoodEntry () {
        waitForAngular();
        final WebDriverWait wait = new WebDriverWait( driver, 30 );
        // wait.until( ExpectedConditions.visibilityOfElementLocated( By.xpath(
        // "//span[@id='submitButton']" ) ) );
        ( (JavascriptExecutor) driver ).executeScript( "document.getElementById('submitButton').click();" );
        waitForAngular();
    }

    /**
     * Log in as HCP
     */
    @When ( "I log in as an HCP" )
    public void loginAsHCP () {
        waitForAngular();
        attemptLogout();
        waitForAngular();
        driver.get( baseUrl );
        setTextField( By.name( "username" ), "HCP" );
        setTextField( By.name( "password" ), "123456" );
        driver.findElement( By.className( "btn" ) ).click();
        waitForAngular();
    }

    /**
     * View patient food diaries
     */
    @And ( "Navigate to view food diaries of patients" )
    public void navigateToPatientFoodDiaries () {
        waitForAngular();
        ( (JavascriptExecutor) driver ).executeScript( "document.getElementById('HCPfooddiaries').click();" );
        waitForAngular();

    }

    /**
     * Select the diary of patient Luke
     */
    @And ( "select a patient with a nonempty food diary" )
    public void selectDiaryPatient () {
        waitForAngular();
        setTextField( By.name( "search" ), "Luke Skywalker" );
        waitForAngular();

        // below was taken from the tests for Emergency records
        final String username = "Luke";
        waitForAngular();
        driver.findElement( By.cssSelector( "input[type=radio][value=" + username + "]" ) ).click();

    }

    /**
     * See Luke's nonempty diary
     */
    @Then ( "I see the patient's nonempty food diary" )
    public void ensureDiaryExists () {
        waitForAngular();
        assertFalse( driver.getPageSource().contains( "has no Food Diary entries" ) );
        assertTrue( driver.getPageSource().contains( "Luke's Food Diary" ) );
        // now look for the two entries we just added as well as the total
        // This code taken from an answer on
        // https://stackoverflow.com/questions/14191935/how-to-find-specific-lines-in-a-table-using-selenium
        final WebElement baseTable = driver.findElement( By.name( "diary_table" ) );
        final List<WebElement> tableRows = baseTable.findElements( By.tagName( "tr" ) );

        final String[] eggsEntry = tableRows.get( 1 ).getText().split( " " );
        final String[] totalEntry = tableRows.get( 2 ).getText().split( " " );

        // make sure all the values shown are as expected
        assertTrue( eggsEntry[0].equals( "10/17/2018" ) );
        assertTrue( eggsEntry[1].equals( "Breakfast" ) );
        assertTrue( eggsEntry[2].equals( "Eggs" ) );
        assertTrue( eggsEntry[3].equals( "1" ) );
        assertTrue( eggsEntry[4].equals( "100" ) );
        assertTrue( eggsEntry[5].equals( "1" ) );
        assertTrue( eggsEntry[6].equals( "2" ) );
        assertTrue( eggsEntry[7].equals( "0" ) );
        assertTrue( eggsEntry[8].equals( "0" ) );
        assertTrue( eggsEntry[9].equals( "0" ) );
        assertTrue( eggsEntry[10].equals( "12" ) );

        // assert that the total correctly multiplies by servings
        assertTrue( totalEntry[0].equals( "10/17/2018" ) );
        assertTrue( totalEntry[1].equals( "Total" ) );
        assertTrue( totalEntry[2].equals( "1" ) );
        assertTrue( totalEntry[3].equals( "100" ) );
        assertTrue( totalEntry[4].equals( "1" ) );
        assertTrue( totalEntry[5].equals( "2" ) );
        assertTrue( totalEntry[6].equals( "0" ) );
        assertTrue( totalEntry[7].equals( "0" ) );
        assertTrue( totalEntry[8].equals( "0" ) );
        assertTrue( totalEntry[9].equals( "12" ) );
        waitForAngular();

    }

    /**
     * Select the diary of patient Obiwan
     */
    @And ( "select a patient with an empty food diary" )
    public void selectNoDiaryPatient () {
        waitForAngular();
        setTextField( By.name( "search" ), "Obiwan Kenobi" );
        waitForAngular();

        // below was taken from the tests for Emergency records
        final String username = "Obiwan";
        waitForAngular();
        driver.findElement( By.cssSelector( "input[type=radio][value=" + username + "]" ) ).click();

    }

    /**
     * See Obiwan's empty food diary
     */
    @Then ( "I see the patient's empty food diary" )
    public void ensureNoDiary () {
        waitForAngular();
        assertFalse( driver.getPageSource().contains( "'s Food Diary" ) );
        assertTrue( driver.getPageSource().contains( "Obiwan" ) );
        assertTrue( driver.getPageSource().contains( "has no Food Diary Entries" ) );
        waitForAngular();

    }
}
