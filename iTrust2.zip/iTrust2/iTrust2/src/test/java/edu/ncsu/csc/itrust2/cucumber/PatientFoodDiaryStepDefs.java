package edu.ncsu.csc.itrust2.cucumber;

import static org.junit.Assert.assertTrue;

import java.util.Calendar;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import edu.ncsu.csc.itrust2.models.persistent.Patient;
import edu.ncsu.csc.itrust2.models.persistent.User;

/**
 * Class to test the patient's food diary functionality.
 *
 * Parts of this, such as the code to create a user, was reused from the
 * PersonalRepresentativesStepDef class.
 *
 * @author saebert
 *
 */
public class PatientFoodDiaryStepDefs extends CucumberTest {

    private final String baseUrl = "http://localhost:8080/iTrust2";

    // taken from PersonalRepresentativeStepDefs
    private void setTextField ( final By byval, final Object value ) {
        final WebElement elem = driver.findElement( byval );
        elem.clear();
        elem.sendKeys( value.toString() );
    }

    // taken from PrescriptionsStepDef
    private void enterValue ( final String name, final String value ) {
        final WebElement field = driver.findElement( By.name( name ) );
        field.clear();
        field.sendKeys( String.valueOf( value ) );
    }

    /**
     * Login as admin and create the needed user Luigi (code taken from
     * PersonalRepresentativesStepDefs with a change to the patient name)
     */
    @Given ( "The relevant patient exists" )
    public void createUser () {
        attemptLogout();

        waitForAngular();
        driver.get( baseUrl );
        setTextField( By.name( "username" ), "admin" );
        setTextField( By.name( "password" ), "123456" );
        driver.findElement( By.className( "btn" ) ).click();
        waitForAngular();

        ( (JavascriptExecutor) driver ).executeScript( "document.getElementById('users').click();" );
        waitForAngular();

        setTextField( By.name( "username" ), "Luigi" );
        setTextField( By.name( "password" ), "123456" );
        setTextField( By.name( "password2" ), "123456" );
        final Select dropdown = new Select( driver.findElement( By.id( "role" ) ) );
        dropdown.selectByVisibleText( "Patient" );
        driver.findElement( By.name( "enabled" ) ).click();
        driver.findElement( By.id( "submit" ) ).click();
        final Patient luigi = new Patient();
        waitForAngular();
        luigi.setSelf( User.getByName( "Luigi" ) );
        luigi.setFirstName( "Luigi" );
        luigi.setLastName( "Smith" );
        final Calendar luigiBirth = Calendar.getInstance();
        luigiBirth.add( Calendar.YEAR, -13 ); // alice is thirteen years old
        luigi.setDateOfBirth( luigiBirth );
        luigi.save();

        waitForAngular();
    }

    /**
     * Login as patient Luigi (Code taken from PersonalRepresentativesStepDefs).
     */
    @Given ( "I am logged in as a patient" )
    public void loginAsLuigi () {
        attemptLogout();

        driver.get( baseUrl );
        setTextField( By.name( "username" ), "luigi" );
        setTextField( By.name( "password" ), "123456" );
        driver.findElement( By.className( "btn" ) ).click();

        waitForAngular();
    }

    /**
     * View food diary
     */
    @When ( "I navigate to my food diary" )
    public void viewFoodDiary () {
        waitForAngular();
        ( (JavascriptExecutor) driver ).executeScript( "document.getElementById('fooddiary').click();" );
        waitForAngular();

    }

    /**
     * Get empty message
     */
    @Then ( "I am shown a message that there are no entries in my food diary" )
    public void checkEmptyFoodDiary () {
        assertTrue( driver.getTitle().contains( "Food Diary" ) );
        assertTrue( driver.getPageSource()
                .contains( "You have no current food diary entries. Add your first entry below." ) );
    }

    /**
     * Navigate to add entry
     */
    @When ( "I navigate to the page to add a food entry" )
    public void addFoodEntry () {
        waitForAngular();
        ( (JavascriptExecutor) driver ).executeScript( "document.getElementById('newEntryButton').click();" );
        waitForAngular();
    }

    /**
     * Fill in food information with the information
     *
     * @param date
     *            date to use
     * @param type
     *            meal type
     * @param name
     *            name of food
     * @param servings
     *            servings of food
     * @param calories
     *            calories of food
     * @param fat
     *            fat of food
     * @param sodium
     *            sodium of food
     * @param carbs
     *            carbs of food
     * @param sugar
     *            sugar of food
     * @param fiber
     *            fiber of food
     * @param protein
     *            protein of food
     * @throws InterruptedException
     */
    @And ( "fill in the form with the information: (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+)" )
    public void fillInForm ( final String date, final String type, final String name, final String servings,
            final String calories, final String fat, final String sodium, final String carbs, final String sugar,
            final String fiber, final String protein ) throws InterruptedException {

        waitForAngular();
        enterValue( "date", date );
        waitForAngular();
        enterValue( "name", name );
        waitForAngular();
        enterValue( "servings", servings );
        waitForAngular();
        enterValue( "calories", calories );
        waitForAngular();
        enterValue( "fat", fat );
        waitForAngular();
        enterValue( "sodium", sodium );

        waitForAngular();
        // This was found at the following website:
        // https://loadfocus.com/blog/2016/06/13/how-to-select-a-dropdown-in-selenium-webdriver-using-java/
        final Select dropdown = new Select( driver.findElement( By.name( "type" ) ) );
        dropdown.selectByVisibleText( type );
        // end credited code

        waitForAngular();
        enterValue( "carbs", carbs );
        waitForAngular();
        enterValue( "sugar", sugar );
        waitForAngular();
        enterValue( "fiber", fiber );
        waitForAngular();
        enterValue( "protein", protein );

        waitForAngular();
        final WebElement submit = driver.findElement( By.id( "submitButton" ) );
        submit.click();

    }

    /**
     * Fill in food information with the information
     *
     * @param date
     *            date to use
     * @param type
     *            meal type
     * @param name
     *            name of food
     * @param servings
     *            servings of food
     * @param calories
     *            calories of food
     * @param fat
     *            fat of food
     * @param sodium
     *            sodium of food
     * @param carbs
     *            carbs of food
     * @param sugar
     *            sugar of food
     * @param fiber
     *            fiber of food
     * @param protein
     *            protein of food
     * @throws InterruptedException
     */
    @And ( "fill in the form with the invalid information: (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+)" )
    public void fillInFormInalid ( final String date, final String type, final String name, final String servings,
            final String calories, final String fat, final String sodium, final String carbs, final String sugar,
            final String fiber, final String protein ) throws InterruptedException {
        waitForAngular();
        enterValue( "date", date );
        waitForAngular();
        enterValue( "name", name );
        waitForAngular();
        enterValue( "servings", servings );
        waitForAngular();
        enterValue( "calories", calories );
        waitForAngular();
        enterValue( "fat", fat );
        waitForAngular();
        enterValue( "sodium", sodium );

        waitForAngular();
        // This was found at the following website:
        // https://loadfocus.com/blog/2016/06/13/how-to-select-a-dropdown-in-selenium-webdriver-using-java/
        final Select dropdown = new Select( driver.findElement( By.name( "type" ) ) );
        dropdown.selectByVisibleText( type );
        // end credited code

        waitForAngular();
        enterValue( "carbs", carbs );
        waitForAngular();
        enterValue( "sugar", sugar );
        waitForAngular();
        enterValue( "fiber", fiber );
        waitForAngular();
        enterValue( "protein", protein );

        waitForAngular();
        final WebElement submit = driver.findElement( By.id( "submitButton" ) );
        submit.click();
    }

    /**
     * The page displays error messages for the invalid fields
     */
    @Then ( "the page shows an error message" )
    public void pageHasErrors () {
        waitForAngular();
        assertTrue( driver.getPageSource().contains( "Date restricted to current or past dates" ) );
        assertTrue( driver.getPageSource().contains( "Please enter zero or a positive value" ) );
    }

    @Then ( "the entries are present in my food diary with correct totals" )
    public void viewDemographics () {

        driver.get( baseUrl );
        ( (JavascriptExecutor) driver ).executeScript( "document.getElementById('fooddiary').click();" );
        waitForAngular();

        assertTrue( driver.getPageSource().contains( "'s Food Diary" ) );

        // now look for the two entries we just added as well as the total
        // This code taken from an answer on
        // https://stackoverflow.com/questions/14191935/how-to-find-specific-lines-in-a-table-using-selenium
        final WebElement baseTable = driver.findElement( By.name( "diary_table" ) );
        final List<WebElement> tableRows = baseTable.findElements( By.tagName( "tr" ) );

        final String[] eggsEntry = tableRows.get( 1 ).getText().split( " " );
        final String[] totalEntry = tableRows.get( 2 ).getText().split( " " );

        // make sure all the values shown are as expected
        assertTrue( eggsEntry[0].equals( "6/13/1997" ) );
        assertTrue( eggsEntry[1].equals( "Breakfast" ) );
        assertTrue( eggsEntry[2].equals( "Eggs" ) );
        assertTrue( eggsEntry[3].equals( "2" ) );
        assertTrue( eggsEntry[4].equals( "100" ) );
        assertTrue( eggsEntry[5].equals( "3" ) );
        assertTrue( eggsEntry[6].equals( "0" ) );
        assertTrue( eggsEntry[7].equals( "10" ) );
        assertTrue( eggsEntry[8].equals( "0" ) );
        assertTrue( eggsEntry[9].equals( "3" ) );
        assertTrue( eggsEntry[10].equals( "4" ) );

        // assert that the total correctly multiplies by servings
        assertTrue( totalEntry[0].equals( "6/13/1997" ) );
        assertTrue( totalEntry[1].equals( "Total" ) );
        assertTrue( totalEntry[2].equals( "2" ) );
        assertTrue( totalEntry[3].equals( "200" ) );
        assertTrue( totalEntry[4].equals( "6" ) );
        assertTrue( totalEntry[5].equals( "0" ) );
        assertTrue( totalEntry[6].equals( "20" ) );
        assertTrue( totalEntry[7].equals( "0" ) );
        assertTrue( totalEntry[8].equals( "6" ) );
        assertTrue( totalEntry[9].equals( "8" ) );
    }

}
